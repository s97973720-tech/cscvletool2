package com.cscvle.tool

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.*
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private val siteUrl = "https://cscvletool.netlify.app"
    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    // Page me download ka naam pakadne ka hook (blob download ke liye)
    private val hookJs = """
        (function(){
          if(window.__cscHook) return; window.__cscHook = true;
          var oc = HTMLAnchorElement.prototype.click;
          HTMLAnchorElement.prototype.click = function(){
            if(this.download) window.__lastDl = this.download;
            return oc.apply(this, arguments);
          };
          document.addEventListener('click', function(e){
            var a = e.target && e.target.closest ? e.target.closest('a') : null;
            if(a && a.download) window.__lastDl = a.download;
          }, true);
        })();
    """.trimIndent()

    private val fileChooser = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { res ->
        val cb = filePathCallback
        filePathCallback = null
        if (cb == null) return@registerForActivityResult
        if (res.resultCode != Activity.RESULT_OK) { cb.onReceiveValue(null); return@registerForActivityResult }
        val data = res.data
        val uris = mutableListOf<Uri>()
        data?.clipData?.let { c -> for (i in 0 until c.itemCount) uris.add(c.getItemAt(i).uri) }
        data?.data?.let { uris.add(it) }
        cb.onReceiveValue(if (uris.isEmpty()) null else uris.toTypedArray())
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = RelativeLayout(this)
        webView = WebView(this)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            layoutParams = RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT, 8
            )
        }
        root.addView(webView, RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT))
        root.addView(progress)
        setContentView(root)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            databaseEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = false
            mediaPlaybackRequiresUserGesture = false
            javaScriptCanOpenWindowsAutomatically = true
        }
        CookieManager.getInstance().setAcceptCookie(true)

        webView.addJavascriptInterface(BlobBridge(), "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                view?.evaluateJavascript(hookJs, null)
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                view?.evaluateJavascript(hookJs, null)
            }
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.startsWith("http://") || url.startsWith("https://") ||
                    url.startsWith("blob:") || url.startsWith("data:")) return false
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))); true
                } catch (e: Exception) { true }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress >= 100) android.view.View.GONE else android.view.View.VISIBLE
            }
            override fun onShowFileChooser(
                webView: WebView?, callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    val accept = params?.acceptTypes?.filter { it.isNotBlank() }
                    if (!accept.isNullOrEmpty()) putExtra(Intent.EXTRA_MIME_TYPES, accept.toTypedArray())
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params?.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                }
                return try { fileChooser.launch(Intent.createChooser(intent, "File chuno")); true }
                catch (e: Exception) { filePathCallback = null; false }
            }
        }

        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            when {
                url.startsWith("blob:") -> {
                    val js = """
                        (function(){
                          var name = window.__lastDl || '';
                          var xhr = new XMLHttpRequest();
                          xhr.open('GET', '$url', true);
                          xhr.responseType = 'blob';
                          xhr.onload = function(){
                            var blob = xhr.response;
                            var r = new FileReader();
                            r.onloadend = function(){
                              AndroidBridge.saveBase64(r.result, blob.type || '$mimeType', name);
                            };
                            r.readAsDataURL(blob);
                          };
                          xhr.send();
                        })();
                    """.trimIndent()
                    webView.evaluateJavascript(js, null)
                }
                url.startsWith("data:") -> {
                    BlobBridge().saveBase64(url, mimeType ?: "", "")
                }
                else -> downloadHttp(url, userAgent, contentDisposition, mimeType)
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })

        if (savedInstanceState != null) webView.restoreState(savedInstanceState)
        else webView.loadUrl(siteUrl)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    private fun downloadHttp(url: String, ua: String?, cd: String?, mime: String?) {
        try {
            val name = URLUtil.guessFileName(url, cd, mime)
            val req = android.app.DownloadManager.Request(Uri.parse(url)).apply {
                setMimeType(mime)
                addRequestHeader("User-Agent", ua)
                addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url) ?: "")
                setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            }
            (getSystemService(DOWNLOAD_SERVICE) as android.app.DownloadManager).enqueue(req)
            Toast.makeText(this, "Download shuru: $name", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Download fail: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    inner class BlobBridge {
        @JavascriptInterface
        fun saveBase64(dataUrl: String, mime: String, suggestedName: String) {
            try {
                val comma = dataUrl.indexOf(',')
                val header = dataUrl.substring(0, comma)
                val bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT)
                val realMime = Regex("data:([^;,]+)").find(header)?.groupValues?.get(1)
                    ?: mime.ifBlank { "application/octet-stream" }
                var name = suggestedName.trim()
                if (name.isEmpty()) {
                    val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(realMime) ?: "bin"
                    name = "CSCVLE_${System.currentTimeMillis()}.$ext"
                }
                name = name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
                saveToDownloads(name, realMime, bytes)
                runOnUiThread { Toast.makeText(this@MainActivity, "Saved in Downloads: $name", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this@MainActivity, "Save fail: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun saveToDownloads(name: String, mime: String, bytes: ByteArray) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw Exception("File nahi ban payi")
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
        } else {
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            dir.mkdirs()
            FileOutputStream(File(dir, name)).use { it.write(bytes) }
        }
    }
}
