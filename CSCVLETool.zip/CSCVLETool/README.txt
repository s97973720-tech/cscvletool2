CSCVLE Tool - Android Studio project
1. Android Studio (Koala ya naya) me File > Open > is folder ko chuno
2. Gradle sync hone do (internet chahiye)
3. Build > Build APK(s)  -> app/build/outputs/apk/debug/app-debug.apk
Play Store ke liye: Build > Generate Signed Bundle/APK
